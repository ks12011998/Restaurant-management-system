<?php
    session_start();
    $item_names = array();
    $prices = array();
    $quantity = array();
    $count=0;
    if(!isset($_GET['id'])){
        echo "INVALID PAGE!";
    }
    $id = $_GET['id'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "food";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    $sql = "SELECT * FROM menu, items where menu.item_id=items.item_id and menu.res_id=$id";
    $result = $conn->query($sql);
    $total = 0;
?>
<html>
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
    <body>
    <div class="container">
        <form method="post" action="../payment_mode.php/">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Item Price</th>
                        <th>Item Quantity</th>
                    </tr>
                </thead>
                <?php
                    while($row = $result->fetch_assoc()){
                        $uid = $row['uid'];
                        $qty = $_POST["$uid"];
                        $total += $row['price'] * $qty;
                        if($qty>0){
                            $item_names[$count] = $row['food_name'];
                            $prices[$count] = $row['price'];
                            $quantity[$count] = $qty;
                            $count++;
                            
                ?>
                <tr>
                    <td><?php echo $row['food_name'] ?> </td>
                    <td><?php echo $row['price']?> </td>
                    <td><?php echo $qty; ?></td>
                </tr>
                <?php
                        }
                    }
                    $_SESSION['items'] = $item_names;
                    $_SESSION['prices'] = $prices;
                    $_SESSION['quantity'] = $quantity;
                    $_SESSION['count'] = $count;
                ?>
            <tr>
                <td>
                     <div>Your total is: <?php echo $total; ?></div>
                </td>
            </tr>

         
            </table>
             <input type="submit" value="pay now" class="btn">
        </form>
         
    </div>
    </body>
<style type="text/css">
   body
{
    background-image: url('../images/back.jpg');
    background-repeat: no-repeat;
    background-size:100% 100%;
    min-height: 700px;
    overflow: hidden;
}
    .container
    {
        transform: translateY(10%);
        background-image: url('../images/container.jpg');
        min-height: 300px;
    }

   .table-bordered
   {
    border-color: black;
   }
</style>

</html>