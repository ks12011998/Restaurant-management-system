<?php
$cardname=$_POST["cardname"];
$cardnumber=$_POST["cardnumber"];
$expmonth=$_POST["expmonth"];
$expyear=$_POST["expyear"];
$cvv=$_POST["cvv"];
if(!empty($cardname) || !empty($cardnumber) || !empty($expmonth) || !empty($expyear) || !empty(cvv))
{

  $host="localhost";
  $username="root";
  $password="";
  $dbname="payment";

$conn= mysqli_connect($host,$username,$password,$dbname);

	if(mysqli_connect_error())
    {
	die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
    }
  else
   {
	$SELECT="SELECT cardnumber From billing Where cardnumber=? Limit=1";
	$INSERT="INSERT INTO billing
	values('$cardname',$cardnumber,'$expmonth','$expyear','$cvv')";
  $result = mysqli_query($conn,$INSERT);
  if(!$result)
	  die(mysqli_error($conn)); 
   }
}
else
{
	echo "all fields are required";
}

?>