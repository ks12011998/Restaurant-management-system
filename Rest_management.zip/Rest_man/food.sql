CREATE DATABASE IF NOT EXISTS FOOD;
CREATE TABLE IF NOT EXISTS items (
food_name varchar(50),
food_type varchar(40),
price int(4),
review int(2)
);

CREATE TABLE if NOT EXISTS restraunt
(
name varchar(50),
location varchar(100),
review int(2),
restraunt_id varchar(40),
food_type varchar(40)
); 
create TABLE if NOT EXISTS customer 
(
cust_name varchar(50),
cust_mob int(10),
cust_email varchar(40),
cust_address varchar(200)

);
insert into items values('chicken-lolipop','non-veg',300,2);
insert into items values('chicken-butter-masala','non-veg',400,5);
insert into items values('chicken-kadhai','non-veg',500,5);
insert into items values('chicken-handi','non-veg',380,4);

insert into restraunt values('kaveri','adityapur',5,'23243','veg && non-veg');
insert into restraunt values('moti-mahal','bistupur',4,'232453','veg');
insert into restraunt values('kaveri','gamahariya',3,'2344543','veg && non-veg');
insert into restraunt values('kaveri','patna',4,'23443','veg && non-veg');
insert into restraunt values('kaveri','ranchi',5,'23365','veg');
insert into restraunt values('station-dhaba','JSR',3,'24543','veg && non-veg');
insert into restraunt values('chinese','bokaro',3,'2344543','veg && non-veg');
insert into restraunt values('junction','jamui',3,'2344543','veg && non-veg');
insert into restraunt values('novelty','kiul',5,'2344543','veg && non-veg');
insert into restraunt values('moti-mahal','narganjo',4,'23543','veg');


insert into customer values('suman',91992336238,'kumarsuman5565@gmail.com','jamui');
insert into customer values('bittu',9999246238,'bittu565@gmail.com','bokaro');
insert into customer values('aakash',912334438,'aakash5565@gmail.com','ranchi');