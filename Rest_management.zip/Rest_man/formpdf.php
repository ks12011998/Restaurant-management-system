<?php 
  session_start();
  $count = $_SESSION['count'];
  $items = $_SESSION['items'];
  $prices = $_SESSION['prices'];
  $quantity = $_SESSION['quantity'];

include_once 'fpdf.php';  
class PDF extends FPDF 
{ 
    // Page header 
    function Header() 
    { 
         $this->Image('images/rest.jpg', 10, 80, 120); 
          
        // GFG logo image 
      
        // Set font-family and font-size 
        $this->SetFont('Times','B',20); 
          
        // Move to the right 
        $this->Cell(80); 
          
       
        // Break line with given space 
        $this->Ln(5); 
    } 
       
    // Page footer 
    function Footer() 
    { 
        // Position at 1.5 cm from bottom 
        $this->SetY(-15); 
          
        // Set font-family and font-size of footer. 
        $this->SetFont('Arial', 'I', 8); 
          
        // set page number 
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . 
              '/{nb}', 0, 0, 'C'); 
    } 
  
// Function to generate OTP 
function generateNumericOTP() 
    { 
    $generator = "1357902468"; 
    $result = ""; 
  
    for ($i = 1; $i <= 6; $i++) { 
        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
    } 

    return $result; 
    }  
} 
function generateNumericOTP() 
    { 
    $generator = "1357902468"; 
    $result = ""; 
  
    for ($i = 1; $i <= 6; $i++) { 
        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
    } 

    return $result; 
    }
   
$name=$_POST['name'];
$mob_no=$_POST['mob_no'];
$address=$_POST['address'];
$email=$_POST['email'];
$city=$_POST['city'];

$pdf = new PDF(); 
$pdf->AliasNbPages(); 
  
// Add new pages 
$pdf->AddPage(); 
  
// Set font-family and font-size. 
$pdf->SetFont('Times','',12); 

$pdf->SetFont('Times', 'B', 12); 
$pdf->cell(60,10,'Name:',1,0);
$pdf->cell(60,10,$name,1,1);
$pdf->cell(60,10,'Mobile:',1,0);
$pdf->cell(60,10,$mob_no,1,1);
$pdf->cell(60,10,'Address:',1,0);
$pdf->cell(60,10,$address,1,1);
$pdf->cell(60,10,'Email:',1,0);
$pdf->cell(60,10,$email,1,1);
$pdf->cell(60,10,'City:',1,0);
$pdf->cell(60,10,$city,1,1);

$pdf->AddPage(); 

for($i = 0; $i < $count; $i++){
    $row = $items[$i].'          '.$prices[$i].'         '.$quantity[$i];
    $pdf->cell(180,10,$row,1,1); 
  }
      
$pdf->Output(); 
  
?>
