<?php
  session_start();
  include ('conn.php');
  include('layout/cssAndJs.php');
?>
<div class = "container">
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" data-target="#myModal">Select  Choices</button>

  <br>
</div>
<?php
  if(isset($_GET['name'])) {
    // $review = mysqli_query($conn, "SELECT id, name, avg(review) FROM restraunt group by restraunt_id having name = '$_GET[name]'");

    $result = mysqli_query($conn,"SELECT * from restraunt where name = '$_GET[name]' and location='$_GET[location]' and review='$_GET[review]'");
    while($row = mysqli_fetch_assoc($result)) {


    echo '<div class="panel panel-default">
      <div class="panel-body">

        <div class = "row">
          <div class = "col-sm-2">
            <img class = "thumbnail" src = "images/bg.jpg" width = "100" height = "100">
          </div>
          <div class = "col-sm-10">
            <p>Name of restraunt: </span><span>'.$row['name'].'</p>
            <p>Location: </span><span>'.$row['location'].'</p>
            <p>Restraunt-id:</span><span>'.$row['restraunt_id'].'</p>
            <p>Type-Available:</span><span>'.$row['food_type'].'</p>
            <a href="restaurant.php/?id='.$row['restraunt_id'].'">View Menu</a>
          </div>
        </div>
      </div>
    </div>';
  }

  } 
  else 
      {

    $result = mysqli_query($conn,"SELECT * FROM restraunt WHERE restraunt_id in (SELECT restraunt_id FROM restraunt ORDER BY review DESC) LIMIT 10");

  while($row = mysqli_fetch_assoc($result)) {

?>
    <div class="panel panel-default">
      <div class="panel-body">

        <div class = "row">
          <div class = "col-sm-2">
            <img class = "thumbnail" src = "images/bg.jpg" width = "100" height = "100">
          </div>
          <div class = "col-sm-10">
              <p>Name of Restraunt: </span><span><?php echo $row['name']?></p>
              <p>Location: </span><span> <?php echo $row['location']?></p>
              <p>Restraunt-id:</span><span><?php echo $row['restraunt_id']?></p>
              <p>Type-Available:</span><span><?php echo $row['food_type'] ?></p>
              <a href="restaurant.php/?id=<?php echo $row['restraunt_id']?>">View Menu</a>         
              <!-- https://techjourney.net/?s=searchterms -->
          </div>
        </div>

      </div>
    </div>

    <?php
      }
    }
?>


<div class = "container">


  <br>
</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Customize</h4>
      </div>
      <div class="modal-body">

        <div class = "row">

          <form method = "GET" action = "exploreitems.php">
            <div class = "col-sm-6">
        
              <div class="form-group">
               
               <?php
                  $result = mysqli_query($conn, "SELECT distinct name from restraunt");

                  while($row = mysqli_fetch_assoc($result)) {
                            
                  }
              ?> 
              </div>
               <div class="form-group">
               <label for="sel1">Name</label>
               <select class="form-control" name="name">
                 <option value="kaveri">Kaveri</option>
                 <option value = "moti-mahal">Moti-mahal</option>
               </select>
              </div>
              <div class="form-group">
               <label for="sel1">Type:</label>
               <select class="form-control" name="food_type">
                 <option value="veg">Veg</option>
                 <option value = "veg && non-veg">Veg && Non-veg</option>
               </select>
              </div>
              <div class="form-group">
               <label for="sel1">Location</label>
               <select class="form-control" name="location">
                 <option value = "Patna">patna</option>
                 <option value = "Ranchi">Ranchi</option>
                 <option value="Jsr">JSR</option>
                 <option value="adityapur">Adityapur</option>
                 <option value="gamahariya">Gamhariya</option>
                 <option value="bistupur">Bistupur</option>
                 <option value="jamui">Jamui</option>
                 <option value="narganjo">Narganjo</option>
               </select>
              </div>
            </div>
            <div class = "col-sm-6">
              <!-- filters  -->

     

              <div class="form-group">
               <label for="sel1">Review:</label>
               <select class="form-control" name="review">
                 <option>1</option>
                 <option>2</option>
                 <option>3</option>
                 <option>4</option>
                 <option>5</option>
               </select>
              </div>
                           
                 <?php

                    $result = mysqli_query($conn, "SELECT distinct location from restraunt");

                    while($row = mysqli_fetch_assoc($result)) {
                        
                    }
                  ?>
      </div>

               </select>
              </div>

            </div>
      <div class="modal-footer">
          <button type="submit" class="btn btn-default">Submit</button>
        </form>

      </div>

        </div>

      </div>
          </div>

  </div>
</div>
<style type="text/css">
.modal-body
{
	min-height: 400px;
}
</style>