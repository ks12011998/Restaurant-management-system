<?php
$host="localhost";
$username="root";
$password="";
$dbname="payment";

$conn= mysqli_connect($host,$username,$password,$dbname);
?>