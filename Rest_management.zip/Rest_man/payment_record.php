<?php
$name=$_POST["name"];
$mob_no=$_POST["mob_no"];
$address=$_POST["address"];
$email=$_POST["email"];
$city=$_POST["city"];

if(!empty($name) || !empty($mob_no) ||  !empty($address) || !empty($email) || !empty($city))
{
$host="localhost";
$username="root";
$password="";
$dbname="payment";

$conn= mysqli_connect($host,$username,$password,$dbname);
if(mysqli_connect_error())
{
	die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
}

else
{
	$SELECT="SELECT email From order_details Where email=? Limit=1";
	$INSERT="INSERT INTO order_details
	values('$name',$mob_no,'$address','$email','$city')";
  $result = mysqli_query($conn,$INSERT);
  if(!$result)
	  die(mysqli_error($conn));
}
}
else
{
	echo "ALL fields are required";
die();}
?>